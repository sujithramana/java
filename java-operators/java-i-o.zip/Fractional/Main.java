import java.util.Scanner;
public class Fraction
{
	public static void main(String[] args) {
	    Scanner obj = new Scanner(System.in);
	    double a = obj.nextDouble();
		System.out.println(a);
	}
}