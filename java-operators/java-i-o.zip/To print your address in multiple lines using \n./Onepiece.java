public class Onepiece {
    public static void main(String[] args) {
        System.out.println("Roronoa Zoro\nEp No: 883\nGrand Line\nWano\nNew World - 1152");
    }
}
