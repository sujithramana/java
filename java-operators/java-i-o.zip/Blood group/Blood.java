import java.util.Scanner;
public class Blood
{
	public static void main(String[] args) {
		Scanner obj = new Scanner(System.in);
		String str = obj.next();
		System.out.println(str);
	}
}
