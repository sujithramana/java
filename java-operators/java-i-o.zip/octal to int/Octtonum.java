import java.util.Scanner;
public class Octtonum
{
	public static void main(String[] args) {
	    Scanner obj = new Scanner(System.in);
	    char a = obj.next().charAt(0);
		System.out.print((int)a);
	}
}