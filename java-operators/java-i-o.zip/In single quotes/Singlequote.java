import java.util.Scanner;
public class Singlequote
{
	public static void main(String[] args) {
	    Scanner obj = new Scanner(System.in);
	    String a = obj.next();
		System.out.print("'"+a+"'");
	}
}