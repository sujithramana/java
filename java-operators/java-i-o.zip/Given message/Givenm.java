import java.util.Scanner;
public class Givenm
{
	public static void main(String[] args) {
	    Scanner obj = new Scanner(System.in);
	    String str = obj.nextLine();
		System.out.println(str);
	}
}
