import java.util.Scanner;
public class Givenw
{
	public static void main(String[] args) {
	    Scanner obj = new Scanner(System.in);
	    String str = obj.next();
		System.out.println(str);
	}
}
