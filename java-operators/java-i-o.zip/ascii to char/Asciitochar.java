import java.util.Scanner;
public class Asciitochart
{
	public static void main(String[] args) {
	    Scanner obj = new Scanner(System.in);
	    int a = obj.nextInt();
		System.out.print((char)a);
	}
}