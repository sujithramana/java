import java.util.Scanner;
public class Twoline
{
	public static void main(String[] args) {
	    Scanner obj = new Scanner(System.in);
	    int a = obj.nextInt();
	    int b = obj.nextInt();
		System.out.print(a+"\n"+b);
	}
}